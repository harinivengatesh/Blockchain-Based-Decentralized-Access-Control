import { useState, useEffect } from 'react';
import './SignatureGenerator.css';

// Helper component for generating signatures in the browser
const SignatureGenerator = ({ onSignatureGenerated, messageToSignExternal, activePrivateKey }) => {
  // privateKey state is no longer needed as it comes from props
  const [messageForDisplay, setMessageForDisplay] = useState(''); 
  const [generatedSignature, setGeneratedSignature] = useState('');
  const [error, setError] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    if (messageToSignExternal) {
      try {
        const parsed = JSON.parse(messageToSignExternal);
        setMessageForDisplay(JSON.stringify(parsed, null, 2));
      } catch (e) {
        setMessageForDisplay(messageToSignExternal);
      }
    } else {
      setMessageForDisplay(''); // Clear if no external message
    }
  }, [messageToSignExternal]);

  const generateSignature = async () => {
    if (!activePrivateKey) {
      setError('No active private key available in the current session.');
      return;
    }
    if (!messageToSignExternal) { // Should always have this if button is enabled
        setError('No message content to sign.');
        return;
    }

    setError('');
    setGeneratedSignature(''); // Clear previous signature
    setIsGenerating(true);
    
    try {
      let pemContents = activePrivateKey.replace(/-----BEGIN PRIVATE KEY-----/, '')
        .replace(/-----END PRIVATE KEY-----/, '')
        .replace(/\s/g, '');
        
      const binaryDer = atob(pemContents);
      const byteArray = new Uint8Array(binaryDer.length);
      for (let i = 0; i < binaryDer.length; i++) {
        byteArray[i] = binaryDer.charCodeAt(i);
      }

      const cryptoKey = await window.crypto.subtle.importKey(
        'pkcs8',
        byteArray.buffer,
        { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
        false,
        ['sign']
      );

      const encoder = new TextEncoder();
      const data = encoder.encode(messageToSignExternal); // Always use the external message for signing
      const signature = await window.crypto.subtle.sign(
        'RSASSA-PKCS1-v1_5',
        cryptoKey,
        data
      );

      const signatureArray = new Uint8Array(signature);
      let binaryString = '';
      for (let i = 0; i < signatureArray.length; i++) {
        binaryString += String.fromCharCode(signatureArray[i]);
      }
      const base64Signature = btoa(binaryString);
      
      setGeneratedSignature(base64Signature);
      if (onSignatureGenerated) {
        onSignatureGenerated(base64Signature);
      }
      setError(''); // Clear error on success
    } catch (err) {
      setError(`Signature Generation Failed: ${err.message}. Ensure the Private Key is correct for the current user session and is in valid PKCS#8 PEM format.`);
      console.error('Signature generation error:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="signature-generator">
      <h4>Generate Signature (using active session key)</h4>
      
      {/* Private Key input is removed */}
      {!activePrivateKey && (
        <p className="info-text">Generate or load a key pair in the "User Registration" section to enable signing.</p>
      )}
      
      <label htmlFor="messageToSignGen">Message to Sign (Auto-filled from request details)</label>
      <textarea
        id="messageToSignGen"
        rows="5"
        value={messageForDisplay}
        readOnly 
        placeholder="Structured message for signing will appear here."
      />
      
      <button 
        onClick={generateSignature} 
        disabled={isGenerating || !activePrivateKey || !messageToSignExternal}
        className="generator-button"
        title={!activePrivateKey ? "No active private key session" : !messageToSignExternal ? "No message content to sign" : "Generate signature"}
      >
        {isGenerating ? 'Generating...' : 'Generate Signature for Request'}
      </button>
      
      {error && <div className="generator-error">{error}</div>}
      
      {generatedSignature && (
        <div className="generated-signature">
          <label>Generated Signature (Base64)</label>
          <textarea readOnly value={generatedSignature} rows="3" />
          <button 
            className="copy-button"
            onClick={() => {
              navigator.clipboard.writeText(generatedSignature);
              alert('Signature copied to clipboard!');
            }}
          >
            Copy Signature
          </button>
        </div>
      )}
    </div>
  );
};

export default SignatureGenerator; 