import { useState, useEffect, useRef } from 'react';
import './BlockchainVisualizer.css';

// --- Helper Functions ---
const generateHash = (blockData) => {
  const str = JSON.stringify(blockData);
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(16).padStart(8, '0').substring(0, 8);
};

const hashToColor = (hash) => {
  if (!hash) return '#cccccc';
  return `#${hash.substring(0, 6)}`;
};

const getBlockValidity = (blocks) => {
  if (!blocks || blocks.length === 0) return [];
  const validity = [true]; 
  for (let i = 1; i < blocks.length; i++) {
    if (!blocks[i-1] || !blocks[i]) continue;
    validity[i] = blocks[i].prevHash === blocks[i - 1].hash;
  }
  return validity;
};

const isChainValid = (blocks) => getBlockValidity(blocks).every(Boolean);

// --- Components ---
const BlockPopover = ({ block, isValid, onTamper, onClose }) => {
  if (!block) return null;
  return (
    <div className="block-popover popover-enter-active">
      <button className="close-btn" onClick={onClose}>×</button>
      <h4><span className="block-icon">🧱</span> Block #{block.index}</h4>
      {!isValid && (
        <div className="popover-warning">
          <span className="warning-icon">⚠️</span> <b>Invalid Block!</b> Hash chain broken.
        </div>
      )}
      <div className="popover-detail"><span className="detail-label">Timestamp:</span> {new Date(block.timestamp).toLocaleString()}</div>
      {block.data && typeof block.data === 'object' && (
        <>
          <div className="popover-detail"><span className="detail-label">Type:</span> {block.data.type || 'N/A'}</div>
          <div className="popover-detail"><span className="detail-label">User:</span> {block.data.username || 'N/A'}</div>
          <div className="popover-detail"><span className="detail-label">Resource:</span> {block.data.resource || 'N/A'}</div>
        </>
      )}
      {typeof block.data === 'string' && <div className="popover-detail"><span className="detail-label">Data:</span> {block.data}</div>}
      <div className="popover-detail"><span className="detail-label">Nonce:</span> {block.nonce}</div>
      <div className="popover-detail"><span className="detail-label">Difficulty:</span> {block.difficulty}</div>
      <div className="popover-detail"><span className="detail-label">Prev Hash:</span> <span className="hash-value hover-glow">{block.prevHash}</span></div>
      <div className="popover-detail"><span className="detail-label">Hash:</span> <span className={`hash-value hover-glow ${block.isTampered ? 'tampered-hash-value' : ''}`}>{block.hash}</span></div>
      {block.originalHash && block.isTampered && (
          <div className="popover-detail"><span className="detail-label">Original Hash:</span> <span className="hash-value hover-glow">{block.originalHash}</span></div>
      )}
      <div className="popover-data-raw">
        <h4><span className="data-icon">📄</span> Raw Data</h4>
        <pre>{JSON.stringify(block.data, null, 2)}</pre>
      </div>
      {block.index > 0 && (
         <button onClick={() => onTamper(block.index)} className={`tamper-button ${block.isTampered ? 'reset-tamper' : ''}`}>
           {block.isTampered ? 'Reset Block Data' : 'Simulate Data Tamper'}
         </button>
      )}
    </div>
  );
};

const MiningIndicator = ({ difficulty }) => (
  <div className="mining-indicator mining-enter-active">
    <div className="pickaxe-container">
      <div className="pickaxe">⛏️</div>
      <div className="sparks">✨</div>
    </div>
    <div className="mining-text">
      <span>MINING NEW BLOCK</span>
      <span className="difficulty-text">Target Difficulty: {difficulty} (hash must start with {Array(difficulty + 1).join('0')})</span>
      <div className="nonce-search">Finding Nonce... <span className="dots"></span></div>
    </div>
  </div>
);

const BlockchainVisualizer = ({ blocks: initialBlocks, highlightNewBlocks = true }) => {
  const [blocks, setBlocks] = useState([]);
  const [isMining, setIsMining] = useState(false);
  const [currentMiningDifficulty, setCurrentMiningDifficulty] = useState(0);
  const [animatedNewBlock, setAnimatedNewBlock] = useState(null); // For new block flow animation
  const [popoverBlock, setPopoverBlock] = useState(null);
  const [popoverBlockIndex, setPopoverBlockIndex] = useState(null);
  const chainContainerRef = useRef(null); // For scrolling the chain

 useEffect(() => {
    const processedBlocks = initialBlocks.map(b => ({ 
        ...b, 
        originalData: JSON.parse(JSON.stringify(b.data)), // Deep copy for reset
        originalHash: b.hash, 
        isTampered: false 
    }));

    if (!initialBlocks || initialBlocks.length === 0) {
        setBlocks([]);
        return;
    }

    if (blocks.length > 0 && initialBlocks.length > blocks.length) {
        const newBlockDataFromApi = initialBlocks.find(ib => !blocks.some(b => b.hash === ib.hash));
        if (newBlockDataFromApi && highlightNewBlocks) {
            const newBlock = {
                ...newBlockDataFromApi,
                originalData: JSON.parse(JSON.stringify(newBlockDataFromApi.data)),
                originalHash: newBlockDataFromApi.hash,
                isTampered: false,
                isNew: true // Flag for animation
            };
            setIsMining(true);
            setCurrentMiningDifficulty(newBlock.difficulty);
            setTimeout(() => {
                setIsMining(false);
                setAnimatedNewBlock(newBlock); // Trigger flow animation
                // Add to blocks list after a delay for flow animation to start
                setTimeout(() => {
                    setBlocks(prev => [newBlock, ...prev.map(b => ({...b, isNew: false}))]);
                    setAnimatedNewBlock(null); // Clear after it's added
                }, 1200); // Duration of flow animation
            }, 2000); // Mining duration
        } else {
            setBlocks(processedBlocks.map(b => ({...b, isNew: false})));
        }
    } else { 
        setBlocks(processedBlocks.map(b => ({...b, isNew: false})));
    }
// eslint-disable-next-line react-hooks/exhaustive-deps
}, [initialBlocks, highlightNewBlocks]);


  useEffect(() => {
    if ((isMining || animatedNewBlock) && chainContainerRef.current) {
      chainContainerRef.current.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  }, [isMining, animatedNewBlock]);
  
  const handleTamper = (blockIndexToTamper) => {
    setBlocks(prevBlocks => {
      const displayIndex = prevBlocks.findIndex(b => b.index === blockIndexToTamper);
      if (displayIndex === -1) return prevBlocks;

      return prevBlocks.map((block, idx) => {
        if (idx === displayIndex) {
          if (block.isTampered) {
            return { ...block, data: JSON.parse(JSON.stringify(block.originalData)), hash: block.originalHash, isTampered: false };
          } else {
            const tamperedData = { ...block.originalData, resource: '[TAMPERED_DATA]', user: 'hacker_x' };
            return {
              ...block,
              data: tamperedData,
              hash: generateHash({ index: block.index, timestamp: block.timestamp, data: tamperedData, prevHash: block.prevHash, nonce: block.nonce }),
              isTampered: true,
            };
          }
        }
        return block;
      });
    });
    // Update popover if it's the tampered block
    if(popoverBlock && popoverBlock.index === blockIndexToTamper){
        const updatedBlock = blocks.find(b => b.index === blockIndexToTamper);
        // This needs to be smarter, as blocks state update is async.
        // For now, just close popover, user can reopen.
        setPopoverBlock(null);
    }
  };

  if (blocks.length === 0 && !isMining) {
    return (
      <div className="blockchain-visualizer-empty">
        <div className="empty-state">
          <div className="pulse-circle"></div>
          <p>No blocks in the chain yet</p>
        </div>
      </div>
    );
  }

  const validity = getBlockValidity([...blocks].reverse()); 
  const chainIsValid = validity.every(Boolean);

  return (
    <div className="blockchain-visualizer" >
      <div className="chain-header">
        <div className="chain-integrity-indicator" title={chainIsValid ? 'Chain is valid' : 'Chain is broken!'}>
          <span className={chainIsValid ? 'integrity-ok' : 'integrity-broken'}>
            {chainIsValid ? '✔ Chain Valid' : '✖ Chain Broken'}
          </span>
        </div>
      </div>
      {isMining && <MiningIndicator difficulty={currentMiningDifficulty} />}
      {animatedNewBlock && (
        <div 
          key={animatedNewBlock.hash} 
          className="block-container new-block-flow-animation"
          style={{borderColor: hashToColor(animatedNewBlock.hash)}}
        >
          <div className="block-header">
            <span className="block-index">#{animatedNewBlock.index}</span>
            <span className="block-timestamp">
              {new Date(animatedNewBlock.timestamp).toLocaleTimeString()}
            </span>
          </div>
          <div className="block-content data-flow-animation">
             <span className="data-flow-text">Block Data Flowing...</span>
             <div className="data-bits"><span></span><span></span><span></span></div>
          </div>
        </div>
      )}
      <div className="blockchain-chain" ref={chainContainerRef}>
        {blocks.map((block, index) => {
          const revIdx = blocks.length - 1 - index; 
          const isValid = validity[revIdx];
          const isPrevValid = revIdx === 0 ? true : validity[revIdx - 1];
          const blockData = block.data || {}; 
          const isLatest = index === 0 && !isMining && !animatedNewBlock;

          return (
            <div key={block.originalHash + (block.isTampered ? '-tampered-' + block.hash : '')} 
                 className={`chain-item ${block.isNew ? 'block-enter-active' : ''}`}>
              <div 
                className={`block-container ${isLatest ? 'latest-block' : ''} ${isValid ? '' : 'invalid-block'} ${block.isTampered ? 'tampered-block' : ''}`}
                style={{ 
                  backgroundColor: `${hashToColor(block.hash)}1A`, // More subtle background
                  borderColor: isValid ? hashToColor(block.hash) : (block.isTampered ? '#e3b341' : '#da3633'),
                }}
                onClick={() => { setPopoverBlock(block); setPopoverBlockIndex(revIdx); }}
                title={`Block #${block.index}${block.isTampered ? ' (Tampered)' : ''}\nNonce: ${block.nonce}\nClick for details`}
              >
                <div className="block-header">
                  <span className="block-index">#{block.index}</span>
                  <span className="block-timestamp">
                    {new Date(block.timestamp).toLocaleTimeString()}
                  </span>
                  <span className={`block-type-icon ${blockData.type}`}
                    title={blockData.type === 'accessGrant' ? 'Access Grant' : (blockData.type || (typeof block.data === 'string' ? 'Genesis' : 'Data' ))}
                  >
                    {blockData.type === 'accessGrant' ? '🔑' : (typeof block.data === 'string' ? '🌍' : '📄')}
                  </span>
                  {!isValid && <span className="block-warning-icon">⚠️</span>}
                  {block.isTampered && <span className="block-tampered-icon">🧬</span>}
                </div>
                <div className="block-content">
                  <div className="data-section">
                    <h4>DATA</h4>
                    <div className="data-visual">
                      {blockData.type === 'accessGrant' ? (
                        <div className="access-grant-data">
                          <span className="grant-label">GRANT</span>
                          <span className="grant-user">{blockData.username}</span>
                          <span className="grant-separator">→</span>
                          <span className="grant-resource">{blockData.resource}</span>
                        </div>
                      ) : (
                        <pre>{typeof block.data === 'string' ? block.data : JSON.stringify(blockData, null, 2)}</pre>
                      )}
                    </div>
                  </div>
                  <div className={`hash-section ${block.isTampered ? 'recalculating-hash' : ''}`}>
                    <div className="hash-visual">
                      <div className="prev-hash hover-glow" style={{ backgroundColor: `${hashToColor(block.prevHash)}EE` }}>
                        <span className="hash-label">PREV HASH</span>
                        <span className="hash-value">{block.prevHash.substring(0, 8)}...</span>
                      </div>
                      <div className="computed-hash hover-glow" style={{ backgroundColor: `${hashToColor(block.hash)}EE` }}>
                        <span className="hash-label">BLOCK HASH</span>
                        <span className={`hash-value ${block.isTampered ? 'tampered-hash-value' : ''}`}>{block.hash.substring(0, 8)}...</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {index < blocks.length - 1 && (
                <div className={`chain-connector ${isValid && isPrevValid ? '' : 'broken-connector'}`} title={isValid && isPrevValid ? 'Valid Link' : 'Chain broken here!'}>
                  <div className={`connector-line hash-link-anim ${isValid && isPrevValid ? '' : 'broken'}`}></div>
                  <div className="connector-arrow"></div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      {popoverBlock && (
        <div className="blockchain-popover-backdrop" onClick={() => setPopoverBlock(null)}>
          <BlockPopover block={popoverBlock} isValid={validity[popoverBlockIndex]} onTamper={handleTamper} onClose={() => setPopoverBlock(null)} />
        </div>
      )}
      <div className="blockchain-legend">
        <span className="legend-item"><span className="legend-box latest"></span> Latest</span>
        <span className="legend-item"><span className="legend-box valid"></span> Valid</span>
        <span className="legend-item"><span className="legend-box invalid"></span> Invalid</span>
        <span className="legend-item"><span className="legend-box tampered"></span> Tampered</span>
        <span className="legend-item"><span className="legend-icon">🔑</span> Access Grant</span>
        <span className="legend-item"><span className="legend-icon">🌍</span> Genesis Block</span>
        <span className="legend-item"><span className="legend-icon">📄</span> Other Data</span>
        <span className="legend-item"><span className="legend-icon">⚠️</span> Invalid Link/Data</span>
        <span className="legend-item"><span className="legend-icon">🧬</span> Tampered</span>
      </div>
      <div className="blockchain-explainer">
        <div className="explainer-header">
          <h3>How Blockchain Works</h3>
        </div>
        <div className="explainer-content">
          <p>This interactive visualization demonstrates key blockchain concepts:</p>
          <ul>
            <li><strong>Blocks:</strong> Contain data, timestamp, nonce, and hashes.</li>
            <li><strong>Chain:</strong> Blocks are linked via cryptographic hashes. Each block's "Prev Hash" must match the "Block Hash" of the preceding block.</li>
            <li><strong>Immutability:</strong> Tampering with a block's data changes its hash, visually breaking the chain from that point onwards.</li>
            <li><strong>Mining (Simulated):</strong> New blocks undergo a "mining" process to find a valid `nonce` that produces a hash meeting a set `difficulty` (e.g., starts with a number of zeros).</li>
          </ul>
          <p>Click on a block to see its details and try the "Simulate Tamper" option (not available for Genesis block).</p>
        </div>
      </div>
    </div>
  );
};

export default BlockchainVisualizer; 