import { useState } from 'react';
import './KeyGenerator.css';

const KeyGenerator = ({ onKeyGenerated }) => {
  const [keyPair, setKeyPair] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState('');

  const generateKeyPair = async () => {
    setError('');
    setIsGenerating(true);
    
    try {
      // Generate a new key pair
      const keyPair = await window.crypto.subtle.generateKey(
        {
          name: 'RSASSA-PKCS1-v1_5',
          modulusLength: 2048,
          publicExponent: new Uint8Array([1, 0, 1]),
          hash: 'SHA-256',
        },
        true,
        ['sign', 'verify']
      );
      
      // Export the public key to SPKI format
      const spkiPublicKey = await window.crypto.subtle.exportKey(
        'spki',
        keyPair.publicKey
      );
      
      // Export the private key to PKCS8 format
      const pkcs8PrivateKey = await window.crypto.subtle.exportKey(
        'pkcs8',
        keyPair.privateKey
      );
      
      // Convert the exported keys to base64
      const publicKeyBase64 = arrayBufferToBase64(spkiPublicKey);
      const privateKeyBase64 = arrayBufferToBase64(pkcs8PrivateKey);
      
      // Format keys as PEM
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${formatPEM(publicKeyBase64)}\n-----END PUBLIC KEY-----`;
      const privateKeyPem = `-----BEGIN PRIVATE KEY-----\n${formatPEM(privateKeyBase64)}\n-----END PRIVATE KEY-----`;
      
      setKeyPair({ publicKey: publicKeyPem, privateKey: privateKeyPem });
      
      if (onKeyGenerated) {
        onKeyGenerated({ publicKey: publicKeyPem, privateKey: privateKeyPem });
      }
    } catch (err) {
      setError(`Failed to generate key pair: ${err.message}`);
      console.error('Key generation error:', err);
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Helper function to convert ArrayBuffer to Base64
  const arrayBufferToBase64 = (buffer) => {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  };
  
  // Helper function to format PEM by adding newlines every 64 characters
  const formatPEM = (base64) => {
    const lines = [];
    for (let i = 0; i < base64.length; i += 64) {
      lines.push(base64.substring(i, i + 64));
    }
    return lines.join('\n');
  };

  return (
    <div className="key-generator">
      <h4>Generate Key Pair</h4>
      
      <button 
        onClick={generateKeyPair} 
        disabled={isGenerating}
        className="generator-button"
      >
        {isGenerating ? 'Generating...' : 'Generate New RSA Key Pair'}
      </button>
      
      {error && <div className="generator-error">{error}</div>}
      
      {keyPair && (
        <div className="generated-keys">
          <div className="key-section">
            <label>Public Key (PEM)</label>
            <textarea readOnly value={keyPair.publicKey} rows="5" />
            <button 
              className="copy-button"
              onClick={() => navigator.clipboard.writeText(keyPair.publicKey)}
            >
              Copy Public Key
            </button>
          </div>
          
          <div className="key-section">
            <label>Private Key (PEM)</label>
            <textarea readOnly value={keyPair.privateKey} rows="5" />
            <button 
              className="copy-button"
              onClick={() => navigator.clipboard.writeText(keyPair.privateKey)}
            >
              Copy Private Key
            </button>
          </div>
          
          <div className="key-warning">
            <p>⚠️ Never share your private key. In a real application, you would keep it secure and never expose it.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default KeyGenerator; 