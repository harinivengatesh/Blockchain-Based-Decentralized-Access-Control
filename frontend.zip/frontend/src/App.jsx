import { useState, useEffect } from 'react';
import './App.css';
import BlockchainVisualizer from './components/BlockchainVisualizer';
// SignatureGenerator component is no longer directly rendered for the main flow
// import SignatureGenerator from './components/SignatureGenerator'; 
import KeyGenerator from './components/KeyGenerator';

const API_BASE = "http://localhost:3001/api";

// Helper: Minimal in-browser signing function (simplified from SignatureGenerator)
async function generateClientSideSignature(privateKeyPem, messageToSign) {
  if (!privateKeyPem || !messageToSign) {
    throw new Error("Private key or message for signing is missing.");
  }
  let pemContents = privateKeyPem.replace(/-----BEGIN PRIVATE KEY-----/, '')
    .replace(/-----END PRIVATE KEY-----/, '')
    .replace(/\s/g, '');
  const binaryDer = atob(pemContents);
  const byteArray = new Uint8Array(binaryDer.length);
  for (let i = 0; i < binaryDer.length; i++) {
    byteArray[i] = binaryDer.charCodeAt(i);
  }
  const cryptoKey = await window.crypto.subtle.importKey(
    'pkcs8',
    byteArray.buffer,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const encoder = new TextEncoder();
  const data = encoder.encode(messageToSign);
  const signature = await window.crypto.subtle.sign(
    'RSASSA-PKCS1-v1_5',
    cryptoKey,
    data
  );
  const signatureArray = new Uint8Array(signature);
  let binaryString = '';
  for (let i = 0; i < signatureArray.length; i++) {
    binaryString += String.fromCharCode(signatureArray[i]);
  }
  return btoa(binaryString);
}

function App() {
  const [users, setUsers] = useState([]);
  const [blockchain, setBlockchain] = useState([]);
  const [message, setMessage] = useState('Welcome! Generate keys and register a user to begin.');

  // Active user session state
  const [activeSessionUser, setActiveSessionUser] = useState(null); // Stores { username, publicKey, privateKey }
  const [generatedPublicKey, setGeneratedPublicKey] = useState(''); // For display before registration
  const [generatedPrivateKey, setGeneratedPrivateKey] = useState(''); // For internal use by KeyGenerator

  const [regUsername, setRegUsername] = useState('');

  const [grantUsername, setGrantUsername] = useState('');
  const [grantResource, setGrantResource] = useState('');

  // Request access form fields (username will be auto-filled from activeSessionUser)
  const [requestResource, setRequestResource] = useState('');
  const [requestMessageDetails, setRequestMessageDetails] = useState('');

  const [showDetails, setShowDetails] = useState(false);

  const fetchUsers = async () => {
    try {
      const response = await fetch(`${API_BASE}/users`);
      const data = await response.json();
      if (response.ok) {
        setUsers(data);
      } else {
        setMessage(`Error fetching users: ${data.error || 'Unknown error'}`);
      }
    } catch (error) {
      setMessage(`Network error fetching users: ${error.message}`);
    }
  };

  const fetchBlockchain = async () => {
    try {
      const response = await fetch(`${API_BASE}/chain`);
      const data = await response.json();
      if (response.ok) {
        setBlockchain(data.slice(-10).reverse()); // Show last 10 blocks, newest first
      } else {
        setMessage(`Error fetching blockchain: ${data.error || 'Unknown error'}`);
      }
    } catch (error) {
      setMessage(`Network error fetching blockchain: ${error.message}`);
    }
  };

  useEffect(() => {
    fetchUsers();
    fetchBlockchain();

    // Set up polling to keep blockchain data updated
    const interval = setInterval(() => {
      fetchBlockchain();
    }, 10000); // Poll every 10 seconds

    return () => clearInterval(interval);
  }, []);

  const handleKeyGenerated = (keyPair) => {
    setGeneratedPublicKey(keyPair.publicKey);
    setGeneratedPrivateKey(keyPair.privateKey);
    setActiveSessionUser(null); // Clear any previous active session as new keys are generated
    setRegUsername(''); // Clear username field too, as it's for new registration
    setMessage('New key pair generated. Enter a username and register.');
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!generatedPublicKey || !generatedPrivateKey) {
      setMessage('Error: Please generate a key pair first using the button above.');
      return;
    }
    if (!regUsername) {
        setMessage('Error: Please enter a username for registration.');
        return;
    }
    setMessage('Registering user...');
    try {
      const response = await fetch(`${API_BASE}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: regUsername, publicKeyPem: generatedPublicKey }),
      });
      const data = await response.json();
      if (response.ok) {
        setActiveSessionUser({
          username: regUsername,
          publicKey: generatedPublicKey,
          privateKey: generatedPrivateKey,
        });
        setMessage(`User '${regUsername}' registered successfully! Session is active. You can now grant/request access.`);
        fetchUsers();
        // Clear fields for next potential registration after this session ends or keys change
        // setGeneratedPublicKey(''); 
        // setGeneratedPrivateKey(''); 
        // setRegUsername(''); 
      } else {
        setMessage(`Registration failed: ${data.error}`);
        setActiveSessionUser(null); // Ensure no active session on failure
      }
    } catch (error) {
      setMessage(`Registration error: ${error.message}`);
      setActiveSessionUser(null);
    }
  };

  const handleGrantAccess = async (e) => {
    e.preventDefault();
    setMessage('Granting access...');
    try {
      const response = await fetch(`${API_BASE}/grant-access`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: grantUsername, resource: grantResource }),
      });
      const data = await response.json();
      if (response.ok) {
        setMessage(`${data.message} (Block: ${data.block.index})`);
        setGrantUsername('');
        setGrantResource('');
        fetchBlockchain(); // Refresh blockchain view
      } else {
        setMessage(`Grant access failed: ${data.error}`);
      }
    } catch (error) {
      setMessage(`Grant access error: ${error.message}`);
    }
  };

  const handleSignAndRequestAccess = async (e) => {
    e.preventDefault(); 
    if (!activeSessionUser || !activeSessionUser.privateKey) {
      setMessage("Error: No active user session with a private key. Please generate keys and register a user first.");
      return;
    }
    if (!requestResource ) {
        setMessage("Error: Resource ID is required for access request.");
        return;
    }

    setMessage('Processing access request...');
    const structuredMessage = {
      action: 'requestAccess',
      user: activeSessionUser.username, // Use active session user
      resource: requestResource,
      timestamp: new Date().toISOString(),
      details: requestMessageDetails || ''
    };
    const messageToSignString = JSON.stringify(structuredMessage);

    try {
      const generatedSignature = await generateClientSideSignature(activeSessionUser.privateKey, messageToSignString);
      
      const response = await fetch(`${API_BASE}/request-access`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: activeSessionUser.username, // Send active session username
          resource: requestResource,
          message: messageToSignString,
          signature: generatedSignature,
        }),
      });
      const data = await response.json();
      if (response.ok) {
        setMessage(data.access ? `✅ Access Granted for '${activeSessionUser.username}' to '${requestResource}': ${data.message}` : `❌ Access Denied for '${activeSessionUser.username}': ${data.reason}`);
        if(data.access) fetchBlockchain();
      } else {
        setMessage(`Access request failed: ${data.error || data.reason}`);
      }
    } catch (error) {
      setMessage(`Access Request Error: ${error.message || 'Failed to generate signature or send request.'}`);
      console.error("Sign and Request Error:", error);
    }
  };

  // QuickAccess can be removed or kept as a dev tool that doesn't use real crypto
  const handleQuickAccess = async () => { /* ... (logic as before, for dev testing if needed) ... */ };

  return (
    <div className="app-container">
      <header>
        <h1>Blockchain-Based Decentralized Access Control</h1>
        <p>Network Security with Backend Interaction Demo</p>
      </header>

      {message && (
        <div className={`message-banner ${message.includes('Denied') || message.includes('failed') || message.includes('Error') ? 'error' : message.includes('Granted') || message.includes('Generated') || message.includes('Success') || message.includes('active') ? 'success' : 'info'}`}>
          {message}
        </div>
      )}

      <div className="main-content">
        <section className="card">
          <h2>1. User Identity & Registration</h2>
          <KeyGenerator onKeyGenerated={handleKeyGenerated} />
          {generatedPublicKey && (
            <form onSubmit={handleRegister} style={{marginTop: '15px'}} className="registration-form">
              <label htmlFor="regUsername">Enter Username for New Keys:</label>
              <input type="text" id="regUsername" value={regUsername} onChange={(e) => setRegUsername(e.target.value)} placeholder="Create a username" required/>
              <label htmlFor="regPublicKey">Public Key (Generated):</label>
              <textarea id="regPublicKey" rows="4" value={generatedPublicKey} readOnly required/>
              <button type="submit" disabled={!generatedPublicKey || !regUsername}>Register This User & Activate Session</button>
            </form>
          )}
        </section>

        <section className="card">
          <h2>2. Grant Access to Resource</h2>
          <form onSubmit={handleGrantAccess}>
            <label htmlFor="grantUsername">Select Registered User:</label>
            <select id="grantUsername" value={grantUsername} onChange={(e) => setGrantUsername(e.target.value)} required disabled={users.length === 0}>
              <option value="">-- Select User --</option>
              {users.map((user) => (<option key={user} value={user}>{user}</option>))}
            </select>
            <label htmlFor="grantResource">Resource ID to Grant:</label>
            <input type="text" id="grantResource" value={grantResource} onChange={(e) => setGrantResource(e.target.value)} placeholder="e.g., document_XYZ" required />
            <button type="submit" disabled={!grantUsername || !grantResource || users.length === 0}>Grant Access on Blockchain</button>
          </form>
        </section>

        <section className="card">
          <h2>3. Request Access as Active User</h2>
          {activeSessionUser ? (
            <form id="accessRequestForm" onSubmit={handleSignAndRequestAccess}>
              <label htmlFor="requestUsernameActive">Active User:</label>
              <input type="text" id="requestUsernameActive" value={activeSessionUser.username} readOnly className="readonly-input"/>
              
              <label htmlFor="requestResource">Resource ID to Access:</label>
              <input type="text" id="requestResource" value={requestResource} onChange={(e) => setRequestResource(e.target.value)} placeholder="e.g., document_XYZ" required />
              
              <label htmlFor="requestMessageDetails">Message Details (Optional):</label>
              <textarea id="requestMessageDetails" rows="2" value={requestMessageDetails} onChange={(e) => setRequestMessageDetails(e.target.value)} placeholder="Additional context for your request" />
              
              <button 
                type="submit" 
                className="sign-and-request-btn" 
                disabled={!requestResource} // Username is fixed, private key is from session
                title={!activeSessionUser.privateKey ? "Internal Error: Private key missing for session" : "Sign with session key and request access"}
              >
                Sign & Request Access for '{activeSessionUser.username}'
              </button>
            </form>
          ) : (
            <p className="info-text">Please generate keys and register a user to activate a session for requesting access.</p>
          )}
        </section>
      </div>

      <section className="blockchain-visual-section card">
        <div className="section-header">
          <h2>Blockchain Ledger Visualization</h2>
          <div className="view-toggle">
            <button 
              className={`toggle-btn ${!showDetails ? 'active' : ''}`} 
              onClick={() => setShowDetails(false)}
            >
              Visual
            </button>
            <button 
              className={`toggle-btn ${showDetails ? 'active' : ''}`} 
              onClick={() => setShowDetails(true)}
            >
              Raw Data
            </button>
          </div>
        </div>
        
        {showDetails ? (
          <div className="log-container">
            {blockchain.length > 0 ? blockchain.map((block) => (
              <div key={block.originalHash + (block.isTampered ? '-tampered-' + block.hash : '')} className="block-entry">
                <p><strong>Index:</strong> {block.index} | <strong>Timestamp:</strong> {new Date(block.timestamp).toLocaleString()}</p>
                <p><strong>Data:</strong> {JSON.stringify(block.data)}</p>
                <p><strong>Nonce:</strong> {block.nonce}</p>
                <p><strong>Difficulty:</strong> {block.difficulty}</p>
                <p><strong>Prev Hash:</strong> <span className="hash-value">{block.prevHash.substring(0, 30)}...</span></p>
                <p><strong>Hash:</strong> <span className={`hash-value ${block.isTampered ? 'tampered-hash-value' : ''}`}>{block.hash.substring(0, 30)}...</span></p>
              </div>
            )) : (
              <p>No blocks in the ledger yet, or unable to load.</p>
            )}
          </div>
        ) : (
          <BlockchainVisualizer blocks={blockchain} />
        )}
      </section>

      <footer>
        &copy; {new Date().getFullYear()} Blockchain Network Security Demo
      </footer>
    </div>
  );
}

export default App; 