const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const crypto = require('crypto');

const app = express();
const PORT = 3001;
const DIFFICULTY = 2; // Number of leading zeros for PoW

app.use(cors());
app.use(bodyParser.json());

// In-memory blockchain ledger simulation for access control
class Blockchain {
  constructor() {
    this.chain = [];
    this.currentIndex = 0;
    this.difficulty = DIFFICULTY;
    // Create the genesis block
    this.addBlock({ data: 'Genesis Block', isGenesis: true });
  }

  computeHash(index, timestamp, data, prevHash, nonce) {
    const str = index + timestamp + JSON.stringify(data) + prevHash + nonce;
    return crypto.createHash('sha256').update(str).digest('hex');
  }

  mineBlock(index, timestamp, data, prevHash) {
    let nonce = 0;
    let hash = '';
    const target = Array(this.difficulty + 1).join('0'); // e.g., '00' for difficulty 2
    console.log(`[MINE] Starting mining for block ${index}. Difficulty: ${this.difficulty} (target: ${target})`);

    // In a real blockchain, this loop would run until a valid hash is found.
    // For simulation, we'll just run it once and use the resulting nonce/hash.
    // To make it slightly more realistic, we can simulate a few attempts.
    let attempts = 0;
    const maxAttempts = 5; // Simulate a few hashing attempts

    do {
      nonce++;
      hash = this.computeHash(index, timestamp, data, prevHash, nonce);
      attempts++;
      // console.log(`[MINE] Attempt ${attempts}: Nonce ${nonce}, Hash ${hash}`); // Optional: very verbose
    } while (hash.substring(0, this.difficulty) !== target && attempts < maxAttempts && !data.isGenesis); // Genesis block bypasses PoW for simplicity
    
    if (hash.substring(0, this.difficulty) !== target && !data.isGenesis) {
        console.log(`[MINE] Could not find valid hash within ${maxAttempts} attempts. Using last attempt for simulation.`);
        // Fallback if target not met in few attempts (for simulation purposes)
        // In a real PoW, the loop continues indefinitely.
    }

    console.log(`[MINE] Block mined for index ${index}: Nonce ${nonce}, Hash ${hash} (after ${attempts} attempts)`);
    return { nonce, hash };
  }

  addBlock(data) {
    const index = this.currentIndex;
    const timestamp = new Date().toISOString();
    const prevHash = this.chain.length ? this.chain[this.chain.length - 1].hash : '0';
    
    const { nonce, hash } = data.isGenesis 
        ? { nonce: 0, hash: this.computeHash(index, timestamp, data.data, prevHash, 0) } 
        : this.mineBlock(index, timestamp, data, prevHash);

    const block = {
      index: index,
      timestamp: timestamp,
      data: data.isGenesis ? data.data : data, // Store actual data, not the wrapper for genesis
      prevHash: prevHash,
      nonce: nonce,
      hash: hash,
      difficulty: this.difficulty // Store difficulty for context
    };

    this.chain.push(block);
    this.currentIndex++;
    console.log(`[BLOCKCHAIN] Block added: Index ${block.index}, Hash ${block.hash}`);
    return block;
  }
}

const blockchain = new Blockchain();

// In-memory user store
// user = { username, publicKeyPem }
const users = new Map();

// Utility to verify signature
function verifySignature(publicKeyPem, signatureBase64, message) {
  try {
    // Simple fallback: if signature == message, we'll accept it for testing purposes
    if (signatureBase64 === message && process.env.NODE_ENV !== 'production') { // Allow only in dev
      console.log('[VERIFY] Using simplified signature verification (message as signature) - TESTING ONLY');
      return true;
    }
    
    // Regular verification
    const verifyCrypto = crypto.createVerify('SHA256');
    verifyCrypto.update(message);
    verifyCrypto.end();
    const signatureBuffer = Buffer.from(signatureBase64, 'base64');
    
    const isValid = verifyCrypto.verify(publicKeyPem, signatureBuffer);
    console.log(`[VERIFY] Signature verification result: ${isValid}`);
    return isValid;
  } catch (error) {
    console.error('[VERIFY] Signature verification error:', error.message);
    return false;
  }
}

// Routes

// Register user: Expects { username, publicKeyPem } => stores user
app.post('/api/register', (req, res) => {
  const { username, publicKeyPem } = req.body;
  if (!username || !publicKeyPem) {
    console.log(`[REGISTER] Failed: Missing username or publicKeyPem. username=${username}, publicKeyPem=${!!publicKeyPem}`);
    return res.status(400).json({ error: 'Missing username or publicKeyPem' });
  }
  if (users.has(username)) {
    console.log(`[REGISTER] Failed: Username already registered. username=${username}`);
    return res.status(400).json({ error: 'Username already registered' });
  }
  users.set(username, { username, publicKeyPem });
  console.log(`[REGISTER] Success: User registered. username=${username}`);
  res.json({ message: `User ${username} registered successfully.` });
});

// Grant access: Expects { resource, username } => adds to blockchain ledger
app.post('/api/grant-access', (req, res) => {
  const { resource, username } = req.body;
  if (!resource || !username) {
    console.log(`[GRANT] Failed: Missing resource or username. username=${username}, resource=${resource}`);
    return res.status(400).json({ error: 'Missing resource or username' });
  }
  if (!users.has(username)) {
    console.log(`[GRANT] Failed: User not found. username=${username}`);
    return res.status(400).json({ error: 'User not found' });
  }
  // Note: addBlock now expects data directly, not wrapped in a 'data' object for non-genesis
  const block = blockchain.addBlock({ type: 'accessGrant', resource, username }); 
  console.log(`[GRANT] Success: Access granted. username=${username}, resource=${resource}, blockIndex=${block.index}`);
  return res.json({ message: `Access granted to user ${username} for resource ${resource}`, block });
});

// Request access: Expects { username, resource, message, signature } => verifies access
app.post('/api/request-access', (req, res) => {
  const { username, resource, message, signature } = req.body;
  console.log(`[REQUEST] Received: user=${username}, res=${resource}, msg=${message ? message.substring(0,30)+'...' : 'N/A'}, sig=${signature ? signature.substring(0,10)+'...' : 'N/A'}`);

  if (!username || !resource || !message || !signature) {
    console.log(`[REQUEST] Failed: Missing one or more required fields. username=${username}, resource=${resource}, message=${!!message}, signature=${!!signature}`);
    return res.status(400).json({ error: 'Missing one or more required fields' });
  }
  if (!users.has(username)) {
    console.log(`[REQUEST] Failed: User not found. username=${username}`);
    return res.status(400).json({ error: 'User not found' });
  }
  
  const user = users.get(username);
  console.log(`[REQUEST] Verifying signature for user ${username} with public key starting with: ${user.publicKeyPem.substring(0,40)}...`);
  
  // Check if blockchain contains access grant for this user and resource
  const hasAccess = blockchain.chain.some(block => 
    block.data && // Ensure block.data exists (especially for genesis block)
    block.data.type === 'accessGrant' &&
    block.data.username === username &&
    block.data.resource === resource
  );
  if (!hasAccess) {
    console.log(`[REQUEST] Failed: Access not granted on blockchain. username=${username}, resource=${resource}`);
    return res.status(403).json({ access: false, reason: 'Access not granted on blockchain' });
  }

  // Verify signature
  const validSignature = verifySignature(user.publicKeyPem, signature, message);
  if (!validSignature) {
    console.log(`[REQUEST] Failed: Invalid signature. username=${username}, resource=${resource}`);
    return res.status(403).json({ access: false, reason: 'Invalid signature' });
  }

  console.log(`[REQUEST] Success: Access granted. username=${username}, resource=${resource}`);
  return res.json({ access: true, message: 'Access granted, signature verified' });
});

// Get users list
app.get('/api/users', (req, res) => {
  res.json(Array.from(users.values()).map(u => u.username));
});

// Get blockchain chain
app.get('/api/chain', (req, res) => {
  res.json(blockchain.chain);
});

app.listen(PORT, () => {
  console.log(`Blockchain Access Control API running on http://localhost:${PORT} with Difficulty ${DIFFICULTY}`);
}); 